import { Route } from '@angular/router';

import { TestComponent } from './test.component';

export const TestRoutes: Route[] = [
	{
		path: 'test',
		component: TestComponent
	}
];
