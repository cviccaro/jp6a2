import { NgModule } from '@angular/core';
import { Http } from '@angular/http';
import { SharedModule } from '../shared/shared.module';
import { TestComponent } from './test.component';

@NgModule({
	imports: [
		SharedModule,
	],
	declarations: [
		TestComponent
	],
	exports: [ TestComponent ]
})
export class TestModule { }
